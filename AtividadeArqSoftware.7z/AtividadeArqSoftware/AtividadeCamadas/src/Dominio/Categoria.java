
public class Categoria {
	
	private int id
	private String nome;

}
