
public class Cidade {
	
	private int id;
	private String nome;

}
