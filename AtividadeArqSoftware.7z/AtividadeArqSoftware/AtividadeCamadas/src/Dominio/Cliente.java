
public class Cliente {
	
	private int id;
	private String nome;
	private String email;
	private String cpfOuCnpj;
	private TipoCliente tipo;
	

}
