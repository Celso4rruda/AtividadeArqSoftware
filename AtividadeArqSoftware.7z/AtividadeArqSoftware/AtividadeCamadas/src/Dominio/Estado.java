
public class Estado {
	private int id;
	private String nome;

}
