
public class ItemPedido {
	
	private double desconto;
	private int quantidade;
	private double preco;

}
