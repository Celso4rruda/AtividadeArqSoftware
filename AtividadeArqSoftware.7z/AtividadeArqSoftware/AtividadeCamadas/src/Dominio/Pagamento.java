
public class Pagamento {
	
	private int id;
	private EstadoPagamento estado;

}
