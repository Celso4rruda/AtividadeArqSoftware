
public class PagamentoComBoleto {
	
	private Date dataVencimento;
	private Date dataPagamento;

}
