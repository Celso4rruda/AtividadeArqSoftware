
public class PagamentoComCartao {
	
	private int numeroDeParcelas;

}
