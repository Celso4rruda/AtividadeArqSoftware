
public class Pedido {
	
	private int id;
	private Date instante;

}
