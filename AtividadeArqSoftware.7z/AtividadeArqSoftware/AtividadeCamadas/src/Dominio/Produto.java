
public class Produto {
	
	private int id;
	private String nome;
	private double preco;

}
