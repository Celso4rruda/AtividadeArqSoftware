
public class Telefone {
	
	private String numero;

}
